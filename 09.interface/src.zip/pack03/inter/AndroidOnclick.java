package pack03.inter;

public interface AndroidOnclick {
	void onClick();
}
